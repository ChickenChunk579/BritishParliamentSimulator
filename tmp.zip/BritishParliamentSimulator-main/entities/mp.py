class MP:
    def __init__(self, name, age, surname):
        self.name = name
        self.age = age
        self.surname = surname