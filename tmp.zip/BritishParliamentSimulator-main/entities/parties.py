class Party:
    def __init__(self, name, mps, pm):
        self.name = name
        self.mps = mps
        self.pm = pm