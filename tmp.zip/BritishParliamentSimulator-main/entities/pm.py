from entities.mp import MP

class PM(MP):
    def __init__(self, name, age, surname):
        super().__init__(name, age, surname)