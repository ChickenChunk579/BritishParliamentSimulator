import json

def load_config():
    return json.load(open("config.json", "r"))